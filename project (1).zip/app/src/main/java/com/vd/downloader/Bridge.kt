package com.vd.downloader

import android.content.ContentValues
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.util.Size
import java.io.FileOutputStream
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.widget.Toast
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/** HTML (JavaScript) থেকে ডাকা হয়। প্রতিটা কাজ ব্যাকগ্রাউন্ডে চলে, শেষে window.__cb(id, ok, data) ডাকে। */
/** এই প্রসেসে এখন কোন ডাউনলোড চলছে (অ্যাপ আবার খুললে একই ডাউনলোড দুবার শুরু না হওয়ার জন্য) */
object RunningKeys {
    val keys: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
}

class Bridge(private val act: MainActivity) {
    private val ctx: Context = act.applicationContext
    private val pool = Executors.newFixedThreadPool(3)
    private val prefs = ctx.getSharedPreferences("vd", Context.MODE_PRIVATE)
    private val dlPool = Executors.newFixedThreadPool(3)
    private val cm: ConnectivityManager = ctx.getSystemService(ConnectivityManager::class.java)

    private class Job(
        val id: Int,
        val url: String,
        val quality: String,
        val key: String,
        val title: String,
        var counted: Boolean = false,
    )

    /** Pause করা / Cancel করা ডাউনলোডের key */
    private val paused = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private val cancelled = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    private fun partialDir(key: String) = File(File(ctx.filesDir, "partial"), key)

    /** Wi-Fi-only অবস্থায় মোবাইল ডাটায় চাপা ডাউনলোডগুলো এখানে জমে থাকে */
    private val pending = java.util.concurrent.CopyOnWriteArrayList<Job>()

    init {
        // নেটওয়ার্ক বদলালে (যেমন Wi-Fi এলে) pending ডাউনলোড শুরু করে
        try {
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { drain() }
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { drain() }
            })
        } catch (_: Throwable) {}
    }

    private fun js(code: String) {
        try {
            act.runOnUiThread {
                try { act.web.evaluateJavascript(code, null) } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    private fun async(id: Int, exec: java.util.concurrent.Executor = pool, block: () -> String) {
        exec.execute {
            try {
                val result = block()
                js("window.__cb($id,true,${JSONObject.quote(result)})")
            } catch (e: Throwable) {
                val msg = (e.message ?: e.toString()).take(300)
                js("window.__cb($id,false,${JSONObject.quote(msg)})")
            }
        }
    }

    private fun jsonLines(text: String): List<JSONObject> =
        text.lineSequence().map { it.trim() }.filter { it.startsWith("{") }
            .mapNotNull { runCatching { JSONObject(it) }.getOrNull() }.toList()

    init {
        // ৩ দিনের পুরনো অসম্পূর্ণ (paused) ফাইল মুছে ফেলে
        try {
            File(ctx.filesDir, "partial").listFiles()
                ?.filter { System.currentTimeMillis() - it.lastModified() > 3L * 24 * 3600 * 1000 }
                ?.forEach { it.deleteRecursively() }
        } catch (_: Throwable) {
        }
    }

    private val running = java.util.concurrent.atomic.AtomicInteger(0)

    init {
        // yt-dlp ইঞ্জিন নিজে থেকে আপডেট (১২ ঘণ্টায় একবার), কারণ YouTube প্রায়ই নিয়ম বদলায়
        pool.execute {
            try {
                val last = prefs.getLong("ytdlp_updated", 0L)
                if (System.currentTimeMillis() - last > 12L * 3600 * 1000) {
                    Engine.await()
                    // ডাউনলোড চলাকালীন ইঞ্জিন আপডেট করলে ডাউনলোড ধীর বা ব্যর্থ হয়; তাই ফাঁকা হওয়ার অপেক্ষা
                    Thread.sleep(45_000)
                    while (running.get() > 0) Thread.sleep(5_000)
                    YoutubeDL.getInstance().updateYoutubeDL(ctx, YoutubeDL.UpdateChannel.NIGHTLY)
                    prefs.edit().putLong("ytdlp_updated", System.currentTimeMillis()).apply()
                }
            } catch (_: Throwable) {
            }
        }
    }

    private fun currentYtdlpVersion(): String = try {
        YoutubeDL.getInstance().version(ctx) ?: ""
    } catch (_: Throwable) {
        ""
    }

    @JavascriptInterface
    fun ytdlpVersion(id: Int) = async(id) {
        Engine.await()
        JSONObject().put("version", currentYtdlpVersion()).toString()
    }

    @JavascriptInterface
    fun updateYtdlp(id: Int) = async(id) {
        Engine.await()
        val r: Any? = YoutubeDL.getInstance().updateYoutubeDL(ctx, YoutubeDL.UpdateChannel.NIGHTLY)
        prefs.edit().putLong("ytdlp_updated", System.currentTimeMillis()).apply()
        JSONObject().put("status", r?.toString() ?: "DONE").put("version", currentYtdlpVersion()).toString()
    }

    @Synchronized
    private fun addHistory(entry: JSONObject) {
        val old = JSONArray(prefs.getString("history", "[]"))
        val arr = JSONArray().put(entry)
        for (i in 0 until minOf(old.length(), 49)) arr.put(old.get(i))
        prefs.edit().putString("history", arr.toString()).apply()
    }

    @JavascriptInterface
    fun config(id: Int) = async(id) {
        JSONObject()
            .put("video_dir", "Movies/VideoDownloader")
            .put("music_dir", "Music/VideoDownloader")
            .put("android", true)
            .toString()
    }

    @JavascriptInterface
    fun history(id: Int) = async(id) { prefs.getString("history", "[]") ?: "[]" }

    @JavascriptInterface
    fun setNotify(on: Boolean) {
        prefs.edit().putBoolean("notify", on).apply()
    }

    @JavascriptInterface
    fun setMobileData(on: Boolean) {
        prefs.edit().putBoolean("mobile", on).apply()
        drain()
    }

    /** এখন কি শুধু মোবাইল ডাটায় আছি (Wi-Fi ছাড়া)? */
    private fun onCellular(): Boolean {
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) &&
            !caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    private fun blocked(): Boolean = !prefs.getBoolean("mobile", true) && onCellular()

    /** pending ডাউনলোড এখন চালানো যাবে কি? (ইন্টারনেট আছে, আর Wi-Fi-only হলে মোবাইল ডাটায় নেই) */
    private fun canRunPending(): Boolean {
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return false
        return prefs.getBoolean("mobile", true) || !caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
    }

    @Synchronized
    private fun drain() {
        if (pending.isEmpty() || !canRunPending()) return
        val jobs = pending.toList()
        pending.clear()
        jobs.forEach { j ->
            js("window.__state(${JSONObject.quote(j.key)},'run')")
            start(j)
        }
    }

    @JavascriptInterface
    fun takeClip(): String {
        val u = act.clipUrl ?: ""
        act.clipUrl = null
        return u
    }

    @JavascriptInterface
    fun takeShared(): String {
        val u = act.sharedUrl ?: ""
        act.sharedUrl = null
        return u
    }

    @JavascriptInterface
    fun toast(msg: String) {
        act.runOnUiThread { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }
    }

    @JavascriptInterface
    fun search(id: Int, query: String) = async(id) {
        Engine.await()
        val req = YoutubeDLRequest("ytsearch12:$query")
        req.addOption("--flat-playlist")
        req.addOption("--dump-json")
        req.addOption("--no-warnings")
        val out = YoutubeDL.getInstance().execute(req).out
        val arr = JSONArray()
        for (j in jsonLines(out)) {
            val vid = j.optString("id")
            if (vid.isEmpty()) continue
            arr.put(
                JSONObject()
                    .put("id", vid)
                    .put("title", j.optString("title"))
                    .put("channel", j.optString("channel", j.optString("uploader")))
                    .put("duration", j.optDouble("duration", 0.0))
                    .put("thumb", "https://i.ytimg.com/vi/$vid/hqdefault.jpg")
                    .put("url", "https://www.youtube.com/watch?v=$vid")
            )
        }
        arr.toString()
    }

    @JavascriptInterface
    fun info(id: Int, url: String) = async(id) {
        Engine.await()
        val req = YoutubeDLRequest(url)
        req.addOption("--dump-json")
        req.addOption("--no-playlist")
        req.addOption("--no-warnings")
        val out = YoutubeDL.getInstance().execute(req).out
        val j = jsonLines(out).firstOrNull() ?: JSONObject()
        JSONObject()
            .put("title", j.optString("title"))
            .put("channel", j.optString("channel", j.optString("uploader")))
            .put("duration", j.optDouble("duration", 0.0))
            .toString()
    }

    /**
     * ডাউনলোড ব্যাকগ্রাউন্ডে চলে (foreground service)।
     * Wi-Fi-only অন থাকলে আর মোবাইল ডাটায় থাকলে ডাউনলোড "pending" থাকে, Wi-Fi এলে নিজে থেকে শুরু হয়।
     */
    @JavascriptInterface
    fun download(id: Int, url: String, quality: String, key: String, title: String) {
        val j = Job(id, url, quality, key, title)
        saveActive(j)
        if (blocked()) {
            // service চালু রাখি, যাতে অ্যাপ ব্যাকগ্রাউন্ডে গেলেও Wi-Fi এলে শুরু করতে পারে
            j.counted = true
            DownloadService.begin(ctx)
            pending.add(j)
            DownloadService.progress(ctx, "Wi-Fi-এর অপেক্ষায় (${pending.size}টি)", -1)
            js("window.__state(${JSONObject.quote(key)},'pending')")
            return
        }
        start(j)
    }

    /** চলমান/অপেক্ষমাণ ডাউনলোডের তালিকা ফাইলে রাখি, যাতে সিস্টেম অ্যাপ বন্ধ করে দিলেও পরে আবার চালানো যায় */
    @Synchronized
    private fun saveActive(j: Job) {
        try {
            val arr = JSONArray(prefs.getString("active_jobs", "[]") ?: "[]")
            val out = JSONArray()
            for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("key") != j.key) out.put(arr.getJSONObject(i))
            out.put(JSONObject().put("key", j.key).put("url", j.url).put("quality", j.quality).put("title", j.title))
            prefs.edit().putString("active_jobs", out.toString()).apply()
        } catch (_: Throwable) {}
    }

    @Synchronized
    private fun removeActive(key: String) {
        try {
            val arr = JSONArray(prefs.getString("active_jobs", "[]") ?: "[]")
            val out = JSONArray()
            for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("key") != key) out.put(arr.getJSONObject(i))
            prefs.edit().putString("active_jobs", out.toString()).apply()
        } catch (_: Throwable) {}
    }

    /** অ্যাপ খোলার সময় ডাকা হয়: যেসব ডাউনলোড শেষ হয়নি সেগুলোর তালিকা (running=true মানে এখনো চলছে) */
    @JavascriptInterface
    fun recover(): String = try {
        val arr = JSONArray(prefs.getString("active_jobs", "[]") ?: "[]")
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val k = o.optString("key")
            if (pending.any { it.key == k }) continue
            o.put("running", k in RunningKeys.keys)
            out.put(o)
        }
        out.toString()
    } catch (_: Throwable) { "[]" }

    @JavascriptInterface
    fun batteryOk(): Boolean = try {
        ctx.getSystemService(android.os.PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
    } catch (_: Throwable) { true }

    /** ব্যাটারি অপ্টিমাইজেশন থেকে বাদ দেওয়ার অনুমতি চায়, যাতে অ্যাপ কেটে দিলেও ডাউনলোড চলে */
    @JavascriptInterface
    fun requestBattery() {
        act.runOnUiThread {
            try {
                act.startActivity(
                    Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:${ctx.packageName}"))
                )
            } catch (_: Throwable) {
                try { act.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Throwable) {}
            }
        }
    }

    private fun start(j: Job) {
        RunningKeys.keys.add(j.key)
        async(j.id, dlPool) { run(j) }
    }

    /** Pause: চলমান প্রসেস থামায়, অসম্পূর্ণ ফাইল রেখে দেয়। Resume করলে সেখান থেকেই চলে। */
    @JavascriptInterface
    fun pause(key: String) {
        paused.add(key)
        removeActive(key)
        try { YoutubeDL.getInstance().destroyProcessById("dl_$key") } catch (_: Throwable) {}
    }

    /** Cancel: ডাউনলোড বন্ধ করে অসম্পূর্ণ ফাইল মুছে দেয়। */
    @JavascriptInterface
    fun cancel(key: String) {
        cancelled.add(key)
        paused.remove(key)
        removeActive(key)
        pending.filter { it.key == key }.forEach {
            pending.remove(it)
            DownloadService.end(ctx)
        }
        val wasRunning = try { YoutubeDL.getInstance().destroyProcessById("dl_$key") } catch (_: Throwable) { false }
        if (!wasRunning) {
            partialDir(key).deleteRecursively()
            cancelled.remove(key)
        }
    }

    private fun run(j: Job): String {
        running.incrementAndGet()
        RunningKeys.keys.add(j.key)
        return try { runInner(j) } finally {
            running.decrementAndGet()
            RunningKeys.keys.remove(j.key)
            if (j.key !in paused) removeActive(j.key)
        }
    }

    private fun runInner(j: Job): String {
        if (!j.counted) DownloadService.begin(ctx)
        paused.remove(j.key)
        cancelled.remove(j.key)
        val tmp = partialDir(j.key).apply { mkdirs() }
        val result: JSONObject = try {
            Engine.await()
            val isAudio = j.quality == "mp3"
            // 403 এলে YouTube-এর অন্য "client" দিয়ে আবার চেষ্টা করে
            // শুধু YouTube-এ client বদলানো দরকার; অন্য সাইটে বারবার চেষ্টা করে সময় নষ্ট করি না।
            // আগে যে client কাজ করেছিল সেটা আগে চেষ্টা করি, তাহলে ব্যর্থ চেষ্টায় সময় যায় না।
            val isYt = Regex("""youtu(\.be|be\.com)""", RegexOption.IGNORE_CASE).containsMatchIn(j.url)
            val all5 = listOf<String?>(null, "android_vr", "web_embedded,web,tv", "mweb", "ios")
            val saved = prefs.getString("yt_client", null)
            val clients: List<String?> = if (!isYt) listOf(null) else {
                val first = all5.firstOrNull { (it ?: "default") == saved }
                if (first != null || saved == "default") listOf(first) + all5.filter { it != first } else all5
            }
            var lastErr: Throwable? = null
            var finished = false
            for ((attempt, client) in clients.withIndex()) {
                if (attempt > 0) tmp.listFiles()?.forEach { it.deleteRecursively() }
                val req = YoutubeDLRequest(j.url)
                req.addOption("--no-playlist")
                req.addOption("--no-warnings")
                req.addOption("-o", "${tmp.absolutePath}/%(title).80s.%(ext)s")
                req.addOption("--socket-timeout", "15")
                req.addOption("-N", "4")
                req.addOption("--write-thumbnail")
                req.addOption("--convert-thumbnails", "jpg")
                if (client != null) req.addOption("--extractor-args", "youtube:player_client=$client")
                if (isAudio) {
                    req.addOption("-f", "bestaudio/best")
                    req.addOption("-x")
                    req.addOption("--audio-format", "mp3")
                } else {
                    val h = j.quality.toIntOrNull() ?: 720
                    // চাওয়া মাপ (ছোট দিক >= h) থাকলে সেটাই; না থাকলে তার চেয়ে বড় সবচেয়ে কাছেরটা।
                    // তার চেয়ে বড় কিছুই না থাকলে সবচেয়ে বড় ছোটটা। height শুধু নয়, width-ও দেখি,
                    // যাতে লম্বা (Shorts/Reels/TikTok) ভিডিওতে ভুল মাপ না আসে।
                    // "+res" মানে সবচেয়ে ছোট মাপ আগে, অর্থাৎ ফিল্টারে টেকা ফরম্যাটগুলোর মধ্যে h-এর সবচেয়ে কাছেরটা।
                    val std = listOf(2160, 1440, 1080, 720, 480, 360, 240, 144)
                    val tiers = listOf(h) + std.filter { it < h }
                    val fsel = tiers.joinToString("/") { t ->
                        "bv*[height>=$t][width>=$t]+ba/b[height>=$t][width>=$t]"
                    } + "/bv*+ba/b"
                    req.addOption("-f", fsel)
                    req.addOption("-S", "+res,ext")
                    req.addOption("--merge-output-format", "mp4")
                }

                var last = -1
                try {
                    YoutubeDL.getInstance().execute(req, "dl_${j.key}") { progress, _, _ ->
                        val p = progress.toInt().coerceIn(0, 100)
                        if (p != last) {
                            last = p
                            js("window.__progress(${j.id},$p)")
                            DownloadService.progress(ctx, j.title, p)
                        }
                    }
                    finished = true
                    if (isYt) prefs.edit().putString("yt_client", client ?: "default").apply()
                    break
                } catch (e: Throwable) {
                    lastErr = e
                    if (j.key in paused || j.key in cancelled) throw e
                    val m = e.message ?: ""
                    val retry = listOf("403", "Forbidden", "format is not available", "n challenge", "nsig")
                        .any { m.contains(it, ignoreCase = true) }
                    if (!retry) break
                }
            }
            if (!finished) throw (lastErr ?: IllegalStateException("ডাউনলোড ব্যর্থ হয়েছে"))

            val all = tmp.listFiles()?.filter { it.isFile } ?: emptyList()
            val imgExt = setOf("jpg", "jpeg", "png", "webp")
            val skipExt = imgExt + setOf("part", "ytdl", "json", "vtt", "srt")
            val file = all.filter { it.extension.lowercase() !in skipExt }.maxByOrNull { it.length() }
                ?: throw IllegalStateException("ফাইল তৈরি হয়নি")
            val thumbSrc = all.firstOrNull { it.extension.lowercase() in imgExt }

            val res = saveToGallery(file, isAudio)
            res.put("thumb", saveThumb(j.key, thumbSrc, Uri.parse(res.getString("uri")), isAudio))
            res.put("audio", isAudio)
            addHistory(
                JSONObject(res.toString())
                    .put("key", j.key)
                    .put("audio", isAudio)
            )
            if (prefs.getBoolean("notify", true)) {
                DownloadService.done(ctx, res.getString("name"), res.getString("uri"), res.getString("mime"))
            }
            res
        } catch (e: Throwable) {
            if (j.key in paused) throw IllegalStateException("PAUSED")
            if (j.key in cancelled) throw IllegalStateException("CANCELLED")
            val raw = e.message ?: e.toString()
            var msg = (raw.lines().lastOrNull { it.contains("ERROR", ignoreCase = true) } ?: raw).take(200)
            if (msg.contains("403")) {
                msg += "\n→ Settings থেকে 'Update downloader engine' চাপুন, তারপর আবার চেষ্টা করুন।"
            }
            addHistory(JSONObject().put("key", j.key).put("err", msg))
            if (prefs.getBoolean("notify", true)) DownloadService.failed(ctx, j.title, msg)
            throw e
        } finally {
            if (j.key !in paused) tmp.deleteRecursively()
            DownloadService.end(ctx)
        }
        return result.toString()
    }

    /** ফাইলটা Movies/VideoDownloader বা Music/VideoDownloader-এ রাখে, তাই গ্যালারি/মিউজিক অ্যাপে দেখা যায়। */
    private fun saveToGallery(file: File, isAudio: Boolean): JSONObject {
        val ext = file.extension.lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: if (isAudio) "audio/mpeg" else "video/mp4"
        val relPath = if (isAudio) "Music/VideoDownloader" else "Movies/VideoDownloader"

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relPath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = if (isAudio) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(collection, values) ?: throw IllegalStateException("সেভ করা যায়নি")
        resolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(uri, values, null, null)

        return JSONObject()
            .put("name", file.name)
            .put("uri", uri.toString())
            .put("mime", mime)
            .put("path", "$relPath/${file.name}")
            .put("size", file.length())
            .put("duration", durationSec(file))
    }

    private fun durationSec(f: File): Double = try {
        val r = MediaMetadataRetriever()
        r.setDataSource(f.absolutePath)
        val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        r.release()
        ms / 1000.0
    } catch (_: Throwable) {
        0.0
    }

    /** থাম্বনেইল অ্যাপের ভেতরের ফোল্ডারে (thumbs/) রাখে, Play ট্যাবে দেখানোর জন্য। */
    private fun saveThumb(key: String, src: File?, mediaUri: Uri, isAudio: Boolean): String {
        val dir = File(ctx.filesDir, "thumbs").apply { mkdirs() }
        val out = File(dir, "$key.jpg")
        try {
            if (src != null && src.length() > 0) {
                src.copyTo(out, overwrite = true)
                return "thumbs/$key.jpg"
            }
            if (!isAudio) {
                val bmp = ctx.contentResolver.loadThumbnail(mediaUri, Size(480, 270), null)
                FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                return "thumbs/$key.jpg"
            }
        } catch (_: Throwable) {
        }
        return ""
    }

    @JavascriptInterface
    @Synchronized
    fun forget(key: String) {
        val old = JSONArray(prefs.getString("history", "[]"))
        val arr = JSONArray()
        for (i in 0 until old.length()) {
            val o = old.getJSONObject(i)
            if (o.optString("key") != key) arr.put(o)
        }
        prefs.edit().putString("history", arr.toString()).apply()
        File(File(ctx.filesDir, "thumbs"), "$key.jpg").delete()
    }

    @JavascriptInterface
    @Synchronized
    fun forgetAll() {
        prefs.edit().putString("history", "[]").apply()
        File(ctx.filesDir, "thumbs").listFiles()?.forEach { it.delete() }
    }

    @JavascriptInterface
    fun deleteFile(id: Int, uri: String) = async(id) {
        ctx.contentResolver.delete(Uri.parse(uri), null, null)
        "true"
    }

    @JavascriptInterface
    fun openFile(uri: String, mime: String) {
        act.runOnUiThread {
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(Uri.parse(uri), mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            try {
                act.startActivity(i)
            } catch (e: Exception) {
                Toast.makeText(act, "ফাইল খোলার অ্যাপ পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @JavascriptInterface
    fun shareFile(uri: String, mime: String) {
        act.runOnUiThread {
            val i = Intent(Intent.ACTION_SEND)
                .setType(mime)
                .putExtra(Intent.EXTRA_STREAM, Uri.parse(uri))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            act.startActivity(Intent.createChooser(i, "Share"))
        }
    }

    /** বাইরের লিংক (যেমন Telegram চ্যানেল) সিস্টেম/Telegram অ্যাপে খোলে */
    @JavascriptInterface
    fun openLink(url: String) {
        if (!url.startsWith("https://")) return
        act.runOnUiThread {
            try {
                act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Throwable) {}
        }
    }

    @JavascriptInterface
    fun openBrowser(url: String) {
        act.runOnUiThread { act.openBrowser(url) }
    }
}
