package com.vd.downloader

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout

/** Facebook/Instagram/TikTok অ্যাপের ভেতরেই খোলে। লগইন নিজে করবেন, ভিডিও খুলে Download চাপলে লিংক মূল পেজে চলে যায়। */
class BrowserActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))

        val fab = Button(this).apply {
            text = "Download"
            setTextColor(Color.BLACK)
            setBackgroundColor(0xFFFFC928.toInt())
            setOnClickListener {
                setResult(RESULT_OK, Intent().putExtra("url", web.url ?: ""))
                finish()
            }
        }
        root.addView(
            fab,
            FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, 36, 56) }
        )
        setContentView(root)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            userAgentString = userAgentString.replace("; wv", "")
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }
        web.webViewClient = WebViewClient()
        web.loadUrl(intent.getStringExtra("url") ?: "https://m.facebook.com/")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else finish()
    }
}
